#Calculate the cost of gas depending on miles driven
#9/30/21
#CTI-110 P2HW1 - Miles Per Gallon
#Conner Hocutt
#
miles = int(input("Enter miles driven: "))
gallons = int(input("Enter gallons used: "))
cost = float(input("Enter cost per gallon: "))
galUsed = miles / gallons
totalCost = gallons * cost
mileCost = totalCost / miles
print("Miles Per Gallon:  ", "%.2f" % galUsed)
print("Total Gas Cost:     ${:.2f}".format(totalCost))
print("Cost Per Mile:      ${:.2f}".format(mileCost))
