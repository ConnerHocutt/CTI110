#Conner Hocutt
#CTI-110
#10/26/21
#Calculate total pay

loop = 1
l = []
m = []
n = []
name = input('Enter employee\'s name: ')
while name != 'None' or name != 'none':
    hours = float(input('Enter number of hours worked: '))
    pay = float(input('Enter hourly pay rate: '))
    if hours > 40:
        overtime = hours - 40
    else:
        overtime = 0
    overPay = overtime * pay
    if overtime <= 0:
        regPay = hours * pay
    else:
        regPay = 40 * pay
    gross = overPay + regPay
    print()
    print('Employee name: ', name)
    print()
    print(f'{"Hours worked":<15}{"Pay rate":<12}{"Overtime":<12}{"Overtime pay":<20}{"RegHour pay":<20}{"Gross pay"}')
    print('-----------------------------------------------------------------------------------------')
    print(f'{hours:<15}{pay:<12}{overtime:<12}{"$"}{overPay:<20.2f}{"$"}{regPay:<20.2f}{"$"}{gross:.2f}')
    print()

    name = input('Enter employee\'s name or \"None\" to terminate: ')
    if name != "None" or name != "none":
        looper = loop + 1
        if looper > 1:
            l.append(overPay)
            m.append(regPay)
            n.append(gross)
            totOvertime = sum(l)
            totRegular = sum(m)
            totGross = sum(n)
    if name == 'None' or name == 'none':
        print('Total number of employees entered: ', looper)
        print('Total amount payed for overtime: ${:.2f}'.format(totOvertime))
        print('Total amount payed for regular hours: ${:.2f}'.format(totRegular))
        print('Total amount payed in gross: ${:.2f}'.format(totGross))
        break
