x = int(input('Enter x: '))
print('x doubled is:', (2 * x))
