#Using IDLE to code user inputs and output calculated information.
#9/23/21
#CTI-110 P1HW2 - Basic Math
#Conner Hocutt
#I still have no idea what pseudocode is but the variables are expense, charge, tax, monthCharge, and yearCharge.
#I used the %.2f format to make the variables stick to 2 decimals and user inputs for expense and charge.
expense = input('Enter name of expense: ')
charge = int(input('Enter monthy charge: '))
print('Bill:', expense, '---------', 'Before Tax: $', float(charge))

#Couldn't get the decimal limiter to work with calculating inside print, so these are separate.
tax = charge * 1.06 - charge
monthCharge = tax + charge
yearCharge = monthCharge * 12

print('Monthly Tax: $', "%.2f" % tax)
print('Monthly Charge: $', "%.2f" % monthCharge)
print('Annual Charge: $', "%.2f" % yearCharge)
