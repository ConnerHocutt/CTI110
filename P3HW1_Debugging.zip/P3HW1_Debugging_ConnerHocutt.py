#Conner Hocutt
#CTI-110
#10/21/21
#Debug a program used to calculate grades
#-------Pseudocode-------
#Display 'Enter your score: '
#Input score
#If score is less or equal to A_score, display 'Your grade is: A'
#If score is inbetween B_score and A_score or equal to B_score, display 'Your grade is: B'
#If score is inbetween C_score and B_score or equal to C_score, display 'Your grade is: C'
#If score is inbetween D_score and C_score or equal to D_score, display 'Your grade is: D'
#If score is less than D_score, display 'Your grade is: F'
score = int(input('Enter your score: '))
def main():
    A_score = 90
    B_score = 80
    C_score = 70
    D_score = 60
    if score >= A_score:
        print('Your grade is: A')
    if score >= B_score and score < A_score:
        print('Your grade is: B')
    if score >= C_score and score < B_score:
        print('Your grade is: C')
    if score >= D_score and score < C_score:
        print('Your grade is: D')
    if score < D_score:
        print('Your grade is: F')
main()
