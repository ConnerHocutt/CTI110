#Conner Hocutt
#CTI-110
#11/23/21
#Gather inputs to subtract from total
#
bank = int(input("Enter amount to be subtracted from: $"))
print()
t = []
u = []
loop = 1
exp = int(input("Enter expense 1: "))
yn = input("Do you want to enter another expense?(y/n) ")
while yn == 'y' or yn == 'Y':
    looper = loop + 1
    t.append(exp)
    print()
    exp = int(input("Enter expense {}: ".format(looper)))
    yn = input("Do you want to enter another expense?(y/n) ")
    print()
    t.append(exp)
    sub = sum(t)
    if yn == 'n' or yn != 'Y':
        print("Amount before expenses subtracted: ${:.2f}".format(bank))
        print("Number of expenses entered: ", looper)
        big = bank - sub
        print("Amount in account after expenses subtracted is ${:.2f}".format(big))
        break
