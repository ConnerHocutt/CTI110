#Conner Hocutt
#CTI-110
#10/26/21
#Calculate total pay
#Display
#Input name
#Display
#Input hours
#Display
#Input pay
#Display '-----------------------------------'
#If hours > 40, set overtime = hours - 40, else set overtime = 0
#Set overPay = overtime * pay
#If overtime <= 0, set regPay = hours * pay, else set regPay = 40 * pay
#Set gross = overPay + regPay
#Display 'Employee name: ', name
#Display '-----------------------------------'
#Display 'Hours worked: ', hours
#Display 'Pay Rate: ', pay
#Display 'OverTime: ', overtime
#Display 'OverTime Pay: ', overPay
#Display 'RegHour Pay: ', regPay
#Display 'Gross Pay: ', gross
name = input('Enter employee\'s name: ')
hours = float(input('Enter number of hours worked: '))
pay = float(input('Enter hourly pay rate: '))
print('-----------------------------------')
if hours > 40:
    overtime = hours - 40
else:
    overtime = 0
overPay = overtime * pay
if overtime <= 0:
    regPay = hours * pay
else:
    regPay = 40 * pay
gross = overPay + regPay

print('Employee name: ', name)
print('-----------------------------------')
print('Hours worked: ', hours)
print('Pay Rate: ', pay)
print('OverTime: ', overtime)
print('OverTime Pay: ', overPay)
print('RegHour Pay: ', regPay)
print('Gross Pay: ', gross)
