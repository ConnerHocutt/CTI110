#CTI-110
#P2HW2 - Lists and Sets
#Conner Hocutt
#39/30/21
#
n1 = float(input("Enter num 1: "))
n2 = float(input("Enter num 2: "))
n3 = float(input("Enter num 3: "))
n4 = float(input("Enter num 4: "))
n5 = float(input("Enter num 5: "))
n6 = float(input("Enter num 6: "))
print()
print("Created List")
list = [n1, n2, n3, n4, n5, n6]
print(list)
list.sort()
print("Smallest number in list: ", min(list))
print("Largest number in list: ", max(list))
total = sum(list)
print("Sum of numbers in list: ", total)
average = total / 6
print("Average of numbers in list: ", average)
print()
print("Created set")
set1 = set(list)
print(set1)

